import express from 'express';
import helmet from 'helmet';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import { spawn } from 'node:child_process';
import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { createReadStream, mkdirSync } from 'node:fs';
import { unlink } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(),port=Number(process.env.PORT||3000),host=process.env.HOST||'0.0.0.0';
const maxBytes=Math.max(1,Number(process.env.MAX_APK_MB||100))*1024*1024;
const timeoutMs=Math.max(10000,Number(process.env.ANALYSIS_TIMEOUT_MS||180000));
const uploadDir=path.join(os.tmpdir(),'rea-mobile-uploads');mkdirSync(uploadDir,{recursive:true});
app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'"],scriptSrc:["'self'"],imgSrc:["'self'","data:"],connectSrc:["'self'"],objectSrc:["'none'"],frameAncestors:["'none'"]}}}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/api/',rateLimit({windowMs:60000,limit:8,standardHeaders:true,legacyHeaders:false}));
function authorized(req){const expected=process.env.REA_ACCESS_TOKEN||'';const actual=req.get('x-rea-token')||'';if(expected.length<24||actual.length!==expected.length)return false;return timingSafeEqual(Buffer.from(actual),Buffer.from(expected));}
const storage=multer.diskStorage({destination:(_r,_f,cb)=>cb(null,uploadDir),filename:(_r,_f,cb)=>cb(null,`${randomUUID()}.apk`)});
const upload=multer({storage,limits:{fileSize:maxBytes,files:1},fileFilter:(_r,file,cb)=>path.extname(file.originalname).toLowerCase()==='.apk'?cb(null,true):cb(new Error('Envie um arquivo .apk.'))});
function sha256(file){return new Promise((resolve,reject)=>{const h=createHash('sha256');createReadStream(file).on('data',b=>h.update(b)).on('error',reject).on('end',()=>resolve(h.digest('hex')));});}
function runRea(apkPath){return new Promise((resolve,reject)=>{const jar=process.env.REA_JADX_MCP_JAR||'/opt/rea/android/jadx-headless-mcp-0.7.1-all.jar';const child=spawn('npx',['--yes','rea-agents@latest','inspect-android-package',apkPath,'--json'],{cwd:os.tmpdir(),shell:false,windowsHide:true,env:{...process.env,CI:'1',REA_JADX_MCP_JAR:jar},stdio:['ignore','pipe','pipe']});let stdout='',stderr='',done=false;const timer=setTimeout(()=>{if(!done){done=true;child.kill('SIGKILL');reject(new Error('Análise excedeu o tempo limite.'));}},timeoutMs);child.stdout.on('data',b=>{if(stdout.length<1_000_000)stdout+=b.toString();});child.stderr.on('data',b=>{if(stderr.length<200_000)stderr+=b.toString();});child.on('error',e=>{if(done)return;done=true;clearTimeout(timer);reject(new Error(`Não foi possível iniciar REA: ${e.message}`));});child.on('close',code=>{if(done)return;done=true;clearTimeout(timer);if(code!==0)return reject(new Error(`REA terminou com código ${code}. ${stderr.slice(-2500)}`));let result;try{result=JSON.parse(stdout);}catch{result={output:stdout};}resolve({result,stderr:stderr.slice(-2500),exitCode:code});});});}
app.get('/api/health',(_r,res)=>res.json({status:'ok',service:'rea-mobile-studio'}));
app.post('/api/analyze',(req,res,next)=>{if(!authorized(req))return res.status(401).json({error:'Código de acesso inválido.'});upload.single('apk')(req,res,err=>err?next(err):analyze(req,res));});
async function analyze(req,res){if(!req.file)return res.status(400).json({error:'Selecione um APK.'});const file=req.file.path;try{const fs=await import('node:fs/promises'),h=await fs.open(file,'r'),head=Buffer.alloc(4);await h.read(head,0,4,0);await h.close();if(!(head[0]===0x50&&head[1]===0x4b&&[3,5,7].includes(head[2])&&[4,6,8].includes(head[3])))return res.status(422).json({error:'O arquivo não parece ser um APK/ZIP válido.'});const info={originalName:path.basename(req.file.originalname).slice(0,120),sizeBytes:req.file.size,sha256:await sha256(file)};const analysis=await runRea(file);res.json({ok:true,file:info,analysis});}catch(e){res.status(500).json({error:e.message||'Falha durante a análise.',hint:'Confira logs do servidor, Java/JDK, JAR JADX e comando REA desta versão.'});}finally{try{await unlink(file);}catch{}}}
app.use((err,_req,res,_next)=>{if(err instanceof multer.MulterError&&err.code==='LIMIT_FILE_SIZE')return res.status(413).json({error:`APK excede o limite de ${process.env.MAX_APK_MB||100} MB.`});res.status(400).json({error:err.message||'Requisição inválida.'});});
if((process.env.REA_ACCESS_TOKEN||'').length<24)console.warn('ATENÇÃO: defina REA_ACCESS_TOKEN com pelo menos 24 caracteres antes de expor o servidor.');
app.listen(port,host,()=>console.log(`REA Mobile Studio ouvindo em ${host}:${port}`));
