# REA Mobile Studio — deployment starter

Interface mobile não oficial para analisar APKs com o REA CLI em servidor Linux. O APK é enviado ao servidor, analisado com `rea inspect-android-package` e removido do diretório temporário ao final.

## O que este pacote prepara

- Dockerfile instala Node.js, JDK 21, `procps` e o JAR JADX 0.7.1.
- Verifica o SHA-256 fixado do JAR antes de continuar.
- Instala as dependências Node automaticamente na imagem.
- Protege o endpoint de análise com um código de acesso (`REA_ACCESS_TOKEN`).
- Inclui `render.yaml` como blueprint de hospedagem.

## Implantação (uma única ação manual ainda necessária)

Não é possível criar/ativar hospedagem externa ou aceitar termos por você. Para usar só o passo final pelo celular:

1. Envie este projeto para um repositório GitHub seu (upload dos arquivos extraídos).
2. No Render, crie um **Blueprint** a partir desse repositório e confirme a implantação. O blueprint gera o token de acesso automaticamente.
3. Depois de concluir, abra o endereço `https://...onrender.com` no Android. Copie o valor de `REA_ACCESS_TOKEN` nas variáveis de ambiente do serviço e cole no campo Código de acesso da página.

**Não compartilhe o token.** Não coloque segredos no GitHub. A configuração inicial ainda exige sua autorização na plataforma de hospedagem; não existe uma URL pública já ativa neste ZIP.

## Rodar localmente com Docker

1. Defina `REA_ACCESS_TOKEN` com um segredo longo (pelo menos 24 caracteres).
2. Execute:
   ```bash
   docker build -t rea-mobile-studio .
   docker run --rm -p 3000:3000 \
     -e REA_ACCESS_TOKEN='coloque-um-segredo-longo-aqui' \
     rea-mobile-studio
   ```
3. Abra `http://localhost:3000`.

## Limitações importantes

- Não é uma integração do ChatGPT/MCP; é uma UI web que chama o REA CLI no servidor.
- A análise real depende de a versão atual do CLI manter o comando e formato JSON usados pelo adaptador. Verifique `rea --help` e `rea inspect-android-package --help` nos logs se houver erro.
- A hospedagem precisa ter memória/CPU suficiente para JADX. Plano gratuito pode dormir, falhar por falta de memória ou não permitir execução adequada; o blueprint usa `starter` como perfil pago de servidor para evitar prometer que uma instância gratuita é suficiente.
- O servidor é público na web, mas a análise exige o token. A limitação de taxa é uma camada adicional, não substitui monitoramento/isolamento.
- Analise apenas APKs que você criou ou tem autorização para examinar. O REA não executa o APK-alvo. Não use resultados para copiar código protegido, contornar licenças, ou extrair segredos/dados privados.
